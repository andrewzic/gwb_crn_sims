#!/bin/bash
voldat="dataset_ranges.csv"
nlines_v=$( cat $voldat | wc -l )

for jj in `seq 1 $nlines_v`
do
    l=$( sed "${jj}q;d" $voldat)
    DP0=$( echo $l | awk -F[','] '{print $5}' )
    DALPHA=$( echo $l | awk -F[','] '{print $6}' )
    echo "DP0 = ";
    echo $DP0
    echo "DALPHA = ";
    echo $DALPHA

    for real in `seq 0 9`; 
    do 
	echo $r ;
	priordat="prior_ranges.csv"
	nlines_p=$( cat $priordat | wc -l)
	for ii in `seq 1 $nlines_p`
	do
	    #echo $ii
	    line=$( sed "${ii}q;d" $priordat)
	    #echo ${line}
	    LGA0=$( echo $line | awk -F[','] '{print $1}' )
	    LGA1=$( echo $line | awk -F[','] '{print $2}' )
	    GAM0=$( echo $line | awk -F[','] '{print $3}' )
	    GAM1=$( echo $line | awk -F[','] '{print $4}' )	    

	    newpf=${DP0}_${DALPHA}_${real}_prior_${LGA0}_${LGA1}_${GAM0}_${GAM1}.dat
	    echo $newpf
	    cp params_all_mc_array_spin_v_spincommon_DP0_DALPHA_20210803_rN_LGA0_LGA1_GAM0_GAM1.dat ${newpf}
	    sed -i "s|DP0|${DP0}|g" $newpf;
	    sed -i "s|DALPHA|${DALPHA}|g" $newpf;
	    sed -i "s|N|${real}|g" $newpf;
	    sed -i "s|LGA0|${LGA0}|g" $newpf
	    sed -i "s|LGA1|${LGA1}|g" $newpf
	    sed -i "s|GAM0|${GAM0}|g" $newpf
	    sed -i "s|GAM1|${GAM1}|g" $newpf	    
	    
	done
	# newpf=${DP0}_${DALPHA}_${GWBA}_${real}_prior_.dat
	# cp params_all_mc_array_spin_v_spincommon_prior_DP0_DALPHA_20210803_rN.dat $newpf;
	# sed -i 's|DP0|'${DP0}'|g' $newpf;
	# sed -i 's|DALPHA|'${DALPHA}'|g' $newpf;
	# sed -i 's|N|'${real}'|g' $newpf;
	# #sed -i 's|zic006/ssb/ptasim/|zic006/pptadr2_gwb_crn_sims/|g' $newpf
    done
done

